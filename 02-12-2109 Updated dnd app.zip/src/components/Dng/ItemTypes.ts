export default {
  FOOD: 'Input',
  GLASS: 'Radio',
  PAPER: 'Checkbox',  
}
